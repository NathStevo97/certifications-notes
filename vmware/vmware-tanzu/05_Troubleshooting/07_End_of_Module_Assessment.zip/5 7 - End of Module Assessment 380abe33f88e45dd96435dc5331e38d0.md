# 5.7 - End of Module Assessment

Tags: Done

1. which two are clusterAPI resources?
    1. machinedeployment & cluster
2. When connecting to a node via SSH, what’s the username?
    1. capv
3. How are arguments passed to Crashd?
    1. —args-file <arg file name>
    2. —args key1=value1