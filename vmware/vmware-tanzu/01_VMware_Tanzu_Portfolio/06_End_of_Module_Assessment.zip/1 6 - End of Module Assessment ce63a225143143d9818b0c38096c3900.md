# 1.6 - End of Module Assessment

Tags: Done

1. What component of TKG manages cluster lifecycle?
    1. Cluster API
2. What’s the purpose of the bootstrap machine?
    1. Used to initialize a management cluster
3. Which configuration file stores management cluster kube contexts?
    1.