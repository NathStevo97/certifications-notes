# 2.9 - End of Module Assessment

Tags: Done

1. What must be uploaded to vCenter Server before deploying TKG?
    1. Base Image Template OVA
2. A TKG Management Cluster can be created by what two methods?
    1. Tanzu CLI
    2. Installer UI
3. Which TKG Component provides cluster authentication functionality?
    1. Pinniped