# 4.14 - End of Module Assessment

Tags: Done

1. What extension provides logging functionality?
    1. Fluent-Bit
2. What extensions facilitate cluster monitoring?
    1. Prometheus and Grafana
3. What extension provides ingress functionality?
    1. Contour