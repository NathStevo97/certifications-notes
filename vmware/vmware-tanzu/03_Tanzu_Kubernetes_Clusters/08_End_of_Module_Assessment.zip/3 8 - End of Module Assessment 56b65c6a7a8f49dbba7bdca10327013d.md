# 3.8 - End of Module Assessment

Tags: Done

1. What’s the parameter that needs to be set to enable autoscaling?
    1. `ENABLE_AUTOSCALER`
2. What component provides high-availability?
    1. `kube-vip`
3. What CNI is provided by default via TKG?
    1. Antrea and Calico